﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("filetools","pl",{loadError:"Błąd podczas odczytu pliku.",networkError:"W trakcie wysyłania pliku pojawił się błąd sieciowy.",httpError404:"Błąd HTTP w trakcie wysyłania pliku (404: Nie znaleziono pliku).",httpError403:"Błąd HTTP w trakcie wysyłania pliku (403: Zabroniony).",httpError:"Błąd HTTP w trakcie wysyłania pliku (status błędu: %1).",noUrlError:"Nie zdefiniowano adresu URL do przesłania pliku.",responseError:"Niepoprawna odpowiedź serwera."});